<?php
mail('support@freehost.com.ua','mail test','mail test');
?>

