<?php
mail('m.erem@vertamedia.com','mail test','mail test');
?>

